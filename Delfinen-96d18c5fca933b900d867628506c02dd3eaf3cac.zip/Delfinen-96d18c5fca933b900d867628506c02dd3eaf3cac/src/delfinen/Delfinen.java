/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package delfinen;

import Data.DataHandling;
import Data.Filehandling;
import Data.User;
import Presentation.GUI;

/**
 *
 * @author simon
 */
public class Delfinen {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new GUI().setVisible(true);
//        Filehandling f = new Filehandling();
//         User u = new User("b", "b", "b", "b", 201291, 99, false, true, true);
//         User u1 = new User("b1", "b", "b", "b", 201291, 99, false, true, true);
//         User u2 = new User("b2", "b", "b", "b", 201291, 99, false, true, true);
//         User u3 = new User("b3", "b", "b", "b", 201291, 99, false, true, true);
//         User u4 = new User("b4", "b", "b", "b", 201291, 99, false, true, true);
//         User u5 = new User("b5", "b", "b", "b", 201291, 99, false, true, true);
//         User u6 = new User("b6", "b", "b", "b", 201291, 99, false, true, true);
//         User u7 = new User("b7", "b", "b", "b", 201291, 99, false, true, true);
//         DataHandling d = new DataHandling();
//         d.addUser(u);
//         d.addUser(u1);
//         d.addUser(u2);
//         d.addUser(u3);
//         d.addUser(u4);
//         d.addUser(u5);
//         d.addUser(u6);
//         d.addUser(u7);
//         u1.setName("c1");
//         f.writeObject(d.getMembers());
//         
    }
}
