
package Data;

import java.util.ArrayList;

public class Team {
    private String name;
    private int ID;
    private ArrayList<User> list = new ArrayList<>();
}
